# Hospital Management System

A comprehensive Hospital Management System built with **Java Spring Boot**, **MySQL**, **HTML**, and **CSS**. This system provides a complete solution for managing patients, doctors, departments, and appointments in a healthcare facility.

## 🏥 Features

### Core Modules
- **Patient Management**: Register, update, and manage patient records
- **Doctor Management**: Manage doctor profiles with specializations and availability
- **Department Management**: Organize hospital departments
- **Appointment Management**: Schedule and track patient appointments

### Technical Features
- RESTful API endpoints for all CRUD operations
- JWT Authentication for secure API access
- API Documentation with Swagger/OpenAPI
- Responsive web interface with Thymeleaf templates
- MySQL database with JPA/Hibernate ORM
- Input validation and error handling
- Modern UI with gradient themes
- Real-time dashboard with statistics
- Docker support for easy deployment

## 🛠️ Technologies Used

- **Backend**: Java 17, Spring Boot 3.1.5
- **Database**: MySQL 8.0+
- **ORM**: Spring Data JPA, Hibernate
- **Frontend**: HTML5, CSS3, Thymeleaf
- **Build Tool**: Maven
- **Additional Libraries**: Lombok, Validation API

## 📋 Prerequisites

Before running this project, ensure you have the following installed:

- Java Development Kit (JDK) 17 or higher
- Maven 3.6+
- MySQL Server 8.0+
- Your favorite IDE (VS Code with Java extensions, IntelliJ IDEA, Eclipse)

## 🚀 Getting Started

### 1. Clone the Repository

```bash
git clone <repository-url>
cd hospital-management-system
```

### 2. Configure MySQL Database

Create a MySQL database and update the credentials in `src/main/resources/application.properties`.

### 3. Run with Docker (Recommended)

The easiest way to run the application is using Docker:

```bash
docker-compose up -d
```

This will start both the application and MySQL database in containers.

### 4. Run Locally

Alternatively, you can run the application locally:

```bash
mvn spring-boot:run
```

### 5. Access the Application

- Web Interface: http://localhost:8080
- API Documentation: http://localhost:8080/swagger-ui.html
- API Endpoints: http://localhost:8080/api/

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/hospital_db?createDatabaseIfNotExist=true
spring.datasource.username=your_mysql_username
spring.datasource.password=your_mysql_password
```

### 3. Build the Project

```bash
mvn clean install
```

### 4. Run the Application

```bash
mvn spring-boot:run
```

Or run the main class:
```bash
java -jar target/hospital-management-system-1.0.0.jar
```

### 5. Access the Application

- **Web Interface**: http://localhost:8080
- **API Base URL**: http://localhost:8080/api

## 📚 API Endpoints

### Patients API
- `GET /api/patients` - Get all patients
- `GET /api/patients/{id}` - Get patient by ID
- `POST /api/patients` - Create new patient
- `PUT /api/patients/{id}` - Update patient
- `DELETE /api/patients/{id}` - Delete patient
- `GET /api/patients/search?term={searchTerm}` - Search patients
- `GET /api/patients/blood-group/{bloodGroup}` - Get patients by blood group

### Doctors API
- `GET /api/doctors` - Get all doctors
- `GET /api/doctors/{id}` - Get doctor by ID
- `POST /api/doctors` - Create new doctor
- `PUT /api/doctors/{id}` - Update doctor
- `DELETE /api/doctors/{id}` - Delete doctor
- `GET /api/doctors/specialization/{specialization}` - Get doctors by specialization
- `GET /api/doctors/available` - Get available doctors
- `GET /api/doctors/department/{departmentId}` - Get doctors by department

### Departments API
- `GET /api/departments` - Get all departments
- `GET /api/departments/{id}` - Get department by ID
- `POST /api/departments` - Create new department
- `PUT /api/departments/{id}` - Update department
- `DELETE /api/departments/{id}` - Delete department
- `GET /api/departments/active` - Get active departments

### Appointments API
- `GET /api/appointments` - Get all appointments
- `GET /api/appointments/{id}` - Get appointment by ID
- `POST /api/appointments` - Create new appointment
- `PUT /api/appointments/{id}` - Update appointment
- `DELETE /api/appointments/{id}` - Delete appointment
- `GET /api/appointments/patient/{patientId}` - Get appointments by patient
- `GET /api/appointments/doctor/{doctorId}` - Get appointments by doctor
- `GET /api/appointments/status/{status}` - Get appointments by status
- `PATCH /api/appointments/{id}/status?status={status}` - Update appointment status

## 💡 Example API Usage

### Create a Patient

```bash
curl -X POST http://localhost:8080/api/patients \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "John",
    "lastName": "Doe",
    "dateOfBirth": "1990-01-15",
    "gender": "Male",
    "phone": "1234567890",
    "email": "john.doe@example.com",
    "address": "123 Main St, City",
    "bloodGroup": "O+"
  }'
```

### Create a Doctor

```bash
curl -X POST http://localhost:8080/api/doctors \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "Sarah",
    "lastName": "Smith",
    "specialization": "Cardiology",
    "qualification": "MBBS, MD",
    "phone": "9876543210",
    "email": "dr.smith@hospital.com",
    "experienceYears": 10,
    "address": "456 Medical Plaza"
  }'
```

### Schedule an Appointment

```bash
curl -X POST http://localhost:8080/api/appointments \
  -H "Content-Type: application/json" \
  -d '{
    "patient": {"id": 1},
    "doctor": {"id": 1},
    "appointmentDateTime": "2024-11-01T10:00:00",
    "reason": "Regular checkup",
    "status": "SCHEDULED"
  }'
```

## 📁 Project Structure

```
hospital-management-system/
├── src/
│   ├── main/
│   │   ├── java/com/hospital/management/
│   │   │   ├── controller/          # REST & Web Controllers
│   │   │   ├── model/               # Entity classes
│   │   │   ├── repository/          # JPA Repositories
│   │   │   ├── service/             # Business logic
│   │   │   └── HospitalManagementSystemApplication.java
│   │   └── resources/
│   │       ├── static/css/          # CSS files
│   │       ├── templates/           # Thymeleaf HTML templates
│   │       ├── application.properties
│   │       └── schema.sql
│   └── test/                        # Test files
├── pom.xml
└── README.md
```

## 🎨 User Interface

The application includes a modern, responsive web interface with:
- Dashboard with real-time statistics
- Patient management interface
- Doctor management interface
- Department management interface
- Appointment scheduling and tracking
- Professional gradient color scheme
- Mobile-responsive design

## 🔒 Security Note

This is a basic implementation for learning and portfolio purposes. For production use, consider adding:
- Spring Security for authentication and authorization
- JWT tokens for API security
- Password encryption
- Role-based access control (RBAC)
- Input sanitization
- CORS configuration

## 🤝 Contributing

This is a portfolio project. Feel free to fork and customize for your own needs.

## 📝 License

This project is open source and available for educational purposes.

## 👨‍💻 Author

Created as a resume project to demonstrate full-stack development skills with Java Spring Boot.

## 📧 Contact

For questions or feedback, please reach out through GitHub.

---

**Note**: Remember to update your MySQL credentials in `application.properties` before running the application!
