# WARP.md

This file provides guidance to WARP (warp.dev) when working with code in this repository.

## Project Overview

Hospital Management System built with Java Spring Boot 3.1.5, MySQL, and Thymeleaf. Manages patients, doctors, departments, and appointments for healthcare facilities.

**Tech Stack**: Java 17, Spring Boot 3.1.5, Spring Data JPA, MySQL 8.0+, Thymeleaf, Lombok, Maven

## Development Commands

### Build & Run
```bash
# Clean and build
mvn clean install

# Run application
mvn spring-boot:run

# Run packaged JAR
java -jar target/hospital-management-system-1.0.0.jar
```

### Testing
```bash
# Run all tests
mvn test

# Run specific test class
mvn test -Dtest=ClassName

# Run with coverage
mvn clean test jacoco:report
```

### Other Maven Commands
```bash
# Clean build artifacts
mvn clean

# Compile without running tests
mvn compile

# Package without running tests
mvn package -DskipTests

# Check for dependency updates
mvn versions:display-dependency-updates
```

## Architecture

### Layered Architecture
The application follows a standard 3-tier Spring Boot architecture:

**Controller Layer** (`controller/`)
- `WebController`: Thymeleaf views serving HTML pages at root paths (/, /patients, /doctors, etc.)
- REST Controllers: RESTful API endpoints under `/api/*` for each entity
- All REST controllers use `@RestController` and return JSON via `ResponseEntity`
- CORS enabled with `@CrossOrigin(origins = "*")` for API development

**Service Layer** (`service/`)
- Business logic for all CRUD operations
- Services are autowired into controllers
- Pattern: `getAllX()`, `getXById()`, `createX()`, `updateX()`, `deleteX()`
- Throws `RuntimeException` when entity not found

**Repository Layer** (`repository/`)
- Spring Data JPA repositories extending `JpaRepository<Entity, Long>`
- Custom query methods using Spring Data naming conventions (e.g., `findByFirstNameContainingIgnoreCase`)
- No `@Query` annotations - relies on method name derivation

### Entity Relationships
- **Doctor** → **Department**: ManyToOne (EAGER fetch, nullable, cascade SET NULL)
- **Appointment** → **Patient**: ManyToOne (EAGER fetch, required, cascade DELETE)
- **Appointment** → **Doctor**: ManyToOne (EAGER fetch, required, cascade DELETE)

All relationships use EAGER fetching to avoid LazyInitializationException in API responses.

### Validation & Data Handling
- Bean Validation API (`jakarta.validation`) annotations on entity fields
- `@Valid` annotation in controller methods for automatic validation
- Phone numbers: 10-digit format validated with regex `^[0-9]{10}$`
- Email validation via `@Email` annotation
- Unique constraints on phone and email fields

### Database Configuration
- MySQL database auto-created if not exists via `createDatabaseIfNotExist=true`
- Hibernate DDL: `spring.jpa.hibernate.ddl-auto=update` (auto-updates schema)
- SQL logging enabled: `spring.jpa.show-sql=true` and `spring.jpa.properties.hibernate.format_sql=true`
- Database credentials in `src/main/resources/application.properties` (default: root/root)

## Key Patterns & Conventions

### Lombok Usage
All entities use `@Data`, `@NoArgsConstructor`, `@AllArgsConstructor` annotations. When modifying entities, maintain this pattern.

### Default Values
- `Patient.registrationDate`: Auto-set to `LocalDate.now()` in entity
- `Appointment.createdAt`: Auto-set to `LocalDateTime.now()` in entity
- `Appointment.status`: Defaults to "SCHEDULED"
- `Doctor.available`: Defaults to `true`
- `Department.active`: Defaults to `true`

### API Response Patterns
- Success: `ResponseEntity.ok(data)` or `ResponseEntity.status(HttpStatus.CREATED).body(data)`
- Not Found: `ResponseEntity.notFound().build()`
- Delete: `ResponseEntity.noContent().build()`

### Date/Time Handling
- Patient DOB: `LocalDate`
- Appointments: `LocalDateTime`
- No timezone handling - assumes server timezone

## Common Modifications

### Adding New Entity
1. Create entity in `model/` with `@Entity`, `@Table`, Lombok annotations
2. Create repository interface in `repository/` extending `JpaRepository`
3. Create service in `service/` with CRUD methods
4. Create REST controller in `controller/` with `@RestController`, `@RequestMapping("/api/entityname")`
5. Add web controller method in `WebController` if UI needed
6. Create Thymeleaf template in `src/main/resources/templates/` if UI needed

### Adding Custom Repository Methods
Use Spring Data JPA method naming conventions:
- `findBy{Field}`: Single result by field
- `findBy{Field}Containing`: LIKE query
- `findBy{Field}ContainingIgnoreCase`: Case-insensitive LIKE
- `findBy{Field1}And{Field2}`: Multiple conditions
- Return `Optional<Entity>` for single results, `List<Entity>` for multiple

### API Endpoint Pattern
```java
@GetMapping("/{id}")
public ResponseEntity<Entity> getById(@PathVariable Long id) {
    return service.getById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
}
```

## Database Setup

Default credentials are `root/root` for MySQL. To change:
1. Edit `src/main/resources/application.properties`
2. Update `spring.datasource.username` and `spring.datasource.password`
3. Ensure MySQL server is running on `localhost:3306`

Application creates database `hospital_db` automatically on first run.

## Web Interface

- Dashboard: http://localhost:9292
- Patients: http://localhost:9292/patients
- Doctors: http://localhost:9292/doctors
- Departments: http://localhost:9292/departments
- Appointments: http://localhost:9292/appointments
- API Base: http://localhost:9292/api

## Port Configuration

Default port is 9292. To change: update `server.port` in `application.properties`.

## Important Notes

- No authentication/authorization implemented - add Spring Security for production
- CORS is wide open (`origins = "*"`) - restrict for production
- Error handling is basic - consider using `@ControllerAdvice` for global exception handling
- No DTO pattern - entities are exposed directly in API responses
- Database password in plaintext - use environment variables for production
