package com.hospital.management.service;

import com.hospital.management.model.Appointment;
import com.hospital.management.repository.AppointmentRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class AppointmentService {
    
    @Autowired
    private AppointmentRepository appointmentRepository;

    @PersistenceContext
    private EntityManager entityManager;
    
    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAll(org.springframework.data.domain.Sort.by("id").ascending());
    }
    
    public Optional<Appointment> getAppointmentById(Long id) {
        return appointmentRepository.findById(id);
    }
    
    public Appointment createAppointment(Appointment appointment) {
        return appointmentRepository.save(appointment);
    }
    
    public Appointment updateAppointment(Long id, Appointment appointmentDetails) {
        Appointment appointment = appointmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Appointment not found with id: " + id));
        
        appointment.setPatient(appointmentDetails.getPatient());
        appointment.setDoctor(appointmentDetails.getDoctor());
        appointment.setAppointmentDateTime(appointmentDetails.getAppointmentDateTime());
        appointment.setStatus(appointmentDetails.getStatus());
        appointment.setReason(appointmentDetails.getReason());
        appointment.setNotes(appointmentDetails.getNotes());
        
        return appointmentRepository.save(appointment);
    }
    
    @Transactional
    public void deleteAppointment(Long id) {
        // Delete the appointment
        appointmentRepository.deleteById(id);
        
        // Reindex remaining appointments to have consecutive IDs starting from 1
        reindexAppointments();
    }
    
    private void reindexAppointments() {
        // Disable foreign key checks temporarily
        entityManager.createNativeQuery("SET FOREIGN_KEY_CHECKS = 0").executeUpdate();
        
        try {
            // Get all remaining appointments ordered by ID
            List<Appointment> appointments = appointmentRepository.findAll(
                org.springframework.data.domain.Sort.by("id").ascending());
            
            if (appointments.isEmpty()) {
                // Reset auto increment if no appointments left
                entityManager.createNativeQuery("ALTER TABLE appointments AUTO_INCREMENT = 1").executeUpdate();
                return;
            }
            
            // First pass: Update to temporary IDs (add large offset to avoid conflicts)
            long tempOffset = 1000000L;
            for (Appointment appointment : appointments) {
                Long oldId = appointment.getId();
                Long tempId = oldId + tempOffset;
                
                if (!oldId.equals(tempId)) {
                    // Update appointment ID to temporary value
                    entityManager.createNativeQuery(
                        "UPDATE appointments SET id = :tempId WHERE id = :oldId")
                        .setParameter("tempId", tempId)
                        .setParameter("oldId", oldId)
                        .executeUpdate();
                }
            }
            
            // Second pass: Update from temporary IDs to final sequential IDs
            // Query appointments again after first pass (they now have temporary IDs)
            @SuppressWarnings("unchecked")
            List<Object[]> tempAppointments = entityManager.createNativeQuery(
                "SELECT id FROM appointments ORDER BY id ASC").getResultList();
            
            for (int i = 0; i < tempAppointments.size(); i++) {
                Long tempId = ((Number) tempAppointments.get(i)[0]).longValue();
                Long newId = (long) (i + 1);
                
                // Update appointment ID to final sequential value
                entityManager.createNativeQuery(
                    "UPDATE appointments SET id = :newId WHERE id = :tempId")
                    .setParameter("newId", newId)
                    .setParameter("tempId", tempId)
                    .executeUpdate();
            }
            
            // Reset auto increment (use tempAppointments size since that's the current count)
            int count = tempAppointments.size();
            entityManager.createNativeQuery(
                "ALTER TABLE appointments AUTO_INCREMENT = :nextId")
                .setParameter("nextId", count + 1)
                .executeUpdate();
            
            // Clear persistence context to reload entities with new IDs
            entityManager.clear();
        } finally {
            // Re-enable foreign key checks
            entityManager.createNativeQuery("SET FOREIGN_KEY_CHECKS = 1").executeUpdate();
        }
    }
    
    public List<Appointment> findByPatientId(Long patientId) {
        return appointmentRepository.findByPatientId(patientId);
    }
    
    public List<Appointment> searchAppointments(String searchTerm) {
        return appointmentRepository.findAll().stream()
                .filter(appointment -> 
                    containsIgnoreCase(appointment.getPatient().getFirstName(), searchTerm) ||
                    containsIgnoreCase(appointment.getPatient().getLastName(), searchTerm) ||
                    containsIgnoreCase(appointment.getDoctor().getFirstName(), searchTerm) ||
                    containsIgnoreCase(appointment.getDoctor().getLastName(), searchTerm) ||
                    containsIgnoreCase(appointment.getReason(), searchTerm) ||
                    containsIgnoreCase(appointment.getStatus().toString(), searchTerm))
                .toList();
    }
    
    private boolean containsIgnoreCase(String str, String searchTerm) {
        return str != null && str.toLowerCase().contains(searchTerm.toLowerCase());
    }
    
    public List<Appointment> findByDoctorId(Long doctorId) {
        return appointmentRepository.findByDoctorId(doctorId);
    }
    
    public List<Appointment> findByStatus(String status) {
        return appointmentRepository.findByStatus(status);
    }
    
    public List<Appointment> findAppointmentsBetween(LocalDateTime start, LocalDateTime end) {
        return appointmentRepository.findByAppointmentDateTimeBetween(start, end);
    }
    
    public Appointment updateAppointmentStatus(Long id, String status) {
        Appointment appointment = appointmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Appointment not found with id: " + id));
        
        appointment.setStatus(status);
        return appointmentRepository.save(appointment);
    }
}
