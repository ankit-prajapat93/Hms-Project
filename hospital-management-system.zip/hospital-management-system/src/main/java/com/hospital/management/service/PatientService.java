package com.hospital.management.service;

import com.hospital.management.model.Patient;
import com.hospital.management.repository.PatientRepository;
import com.hospital.management.exception.UniqueConstraintViolationException;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PatientService {
    
    @Autowired
    private PatientRepository patientRepository;

    @PersistenceContext
    private EntityManager entityManager;
    
    public List<Patient> getAllPatients() {
        return patientRepository.findAll(org.springframework.data.domain.Sort.by("id").ascending());
    }
    
    public Optional<Patient> getPatientById(Long id) {
        return patientRepository.findById(id);
    }
    
    public Patient createPatient(Patient patient) {
        if (patient.getId() != null && patientRepository.existsById(patient.getId())) {
            throw new UniqueConstraintViolationException("A patient with this ID already exists");
        }
        return patientRepository.save(patient);
    }
    
    public Patient updatePatient(Long id, Patient patientDetails) {
        Patient patient = patientRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Patient not found with id: " + id));
        
        patient.setFirstName(patientDetails.getFirstName());
        patient.setLastName(patientDetails.getLastName());
        patient.setDateOfBirth(patientDetails.getDateOfBirth());
        patient.setGender(patientDetails.getGender());
        if (patientDetails.getPhone() != null) patient.setPhone(patientDetails.getPhone());
        if (patientDetails.getEmail() != null) patient.setEmail(patientDetails.getEmail());
        patient.setAddress(patientDetails.getAddress());
        patient.setBloodGroup(patientDetails.getBloodGroup());
        patient.setMedicalHistory(patientDetails.getMedicalHistory());
        
        return patientRepository.save(patient);
    }
    
    @Transactional
    public void deletePatient(Long id) {
        // Delete the patient
        patientRepository.deleteById(id);
        
        // Reindex remaining patients to have consecutive IDs starting from 1
        reindexPatients();
    }
    
    private void reindexPatients() {
        // Disable foreign key checks temporarily
        entityManager.createNativeQuery("SET FOREIGN_KEY_CHECKS = 0").executeUpdate();
        
        try {
            // Get all remaining patients ordered by ID
            List<Patient> patients = patientRepository.findAll(
                org.springframework.data.domain.Sort.by("id").ascending());
            
            if (patients.isEmpty()) {
                // Reset auto increment if no patients left
                entityManager.createNativeQuery("ALTER TABLE patients AUTO_INCREMENT = 1").executeUpdate();
                return;
            }
            
            // First pass: Update to temporary IDs (add large offset to avoid conflicts)
            long tempOffset = 1000000L;
            for (Patient patient : patients) {
                Long oldId = patient.getId();
                Long tempId = oldId + tempOffset;
                
                if (!oldId.equals(tempId)) {
                    // Update appointments that reference this patient
                    entityManager.createNativeQuery(
                        "UPDATE appointments SET patient_id = :tempId WHERE patient_id = :oldId")
                        .setParameter("tempId", tempId)
                        .setParameter("oldId", oldId)
                        .executeUpdate();
                    
                    // Update patient ID to temporary value
                    entityManager.createNativeQuery(
                        "UPDATE patients SET id = :tempId WHERE id = :oldId")
                        .setParameter("tempId", tempId)
                        .setParameter("oldId", oldId)
                        .executeUpdate();
                }
            }
            
            // Second pass: Update from temporary IDs to final sequential IDs
            // Query patients again after first pass (they now have temporary IDs)
            @SuppressWarnings("unchecked")
            List<Object[]> tempPatients = entityManager.createNativeQuery(
                "SELECT id FROM patients ORDER BY id ASC").getResultList();
            
            for (int i = 0; i < tempPatients.size(); i++) {
                Long tempId = ((Number) tempPatients.get(i)[0]).longValue();
                Long newId = (long) (i + 1);
                
                // Update appointments that reference this patient
                entityManager.createNativeQuery(
                    "UPDATE appointments SET patient_id = :newId WHERE patient_id = :tempId")
                    .setParameter("newId", newId)
                    .setParameter("tempId", tempId)
                    .executeUpdate();
                
                // Update patient ID to final sequential value
                entityManager.createNativeQuery(
                    "UPDATE patients SET id = :newId WHERE id = :tempId")
                    .setParameter("newId", newId)
                    .setParameter("tempId", tempId)
                    .executeUpdate();
            }
            
            // Reset auto increment (use tempPatients size since that's the current count)
            int count = tempPatients.size();
            entityManager.createNativeQuery(
                "ALTER TABLE patients AUTO_INCREMENT = :nextId")
                .setParameter("nextId", count + 1)
                .executeUpdate();
            
            // Clear persistence context to reload entities with new IDs
            entityManager.clear();
        } finally {
            // Re-enable foreign key checks
            entityManager.createNativeQuery("SET FOREIGN_KEY_CHECKS = 1").executeUpdate();
        }
    }
    
    public List<Patient> searchPatients(String searchTerm) {
        return patientRepository.findAll().stream()
                .filter(patient -> 
                    containsIgnoreCase(patient.getFirstName(), searchTerm) ||
                    containsIgnoreCase(patient.getLastName(), searchTerm) ||
                    containsIgnoreCase(patient.getEmail(), searchTerm) ||
                    containsIgnoreCase(patient.getPhone(), searchTerm) ||
                    containsIgnoreCase(patient.getBloodGroup(), searchTerm))
                .toList();
    }
    
    private boolean containsIgnoreCase(String str, String searchTerm) {
        return str != null && str.toLowerCase().contains(searchTerm.toLowerCase());
    }
    
    public Optional<Patient> findByPhone(String phone) {
        return patientRepository.findByPhone(phone);
    }
    
    public List<Patient> findByBloodGroup(String bloodGroup) {
        return patientRepository.findByBloodGroup(bloodGroup);
    }
}
