package com.hospital.management.service;

import com.hospital.management.model.Department;
import com.hospital.management.repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

@Service
public class DepartmentService {
    
    @Autowired
    private DepartmentRepository departmentRepository;
    
    public List<Department> getAllDepartments() {
        return departmentRepository.findAll(org.springframework.data.domain.Sort.by("id").ascending());
    }

    public Page<Department> getDepartments(Pageable pageable) {
        return departmentRepository.findAll(pageable);
    }
    
    public Optional<Department> getDepartmentById(Long id) {
        return departmentRepository.findById(id);
    }
    
    public Department createDepartment(Department department) {
        if (department.getId() != null && departmentRepository.existsById(department.getId())) {
            throw new com.hospital.management.exception.UniqueConstraintViolationException("A department with this ID already exists");
        }
        return departmentRepository.save(department);
    }
    
    public Department updateDepartment(Long id, Department departmentDetails) {
        Department department = departmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Department not found with id: " + id));
        
        department.setName(departmentDetails.getName());
        department.setDescription(departmentDetails.getDescription());
        department.setActive(departmentDetails.getActive());
        
        return departmentRepository.save(department);
    }
    
    public void deleteDepartment(Long id) {
        departmentRepository.deleteById(id);
    }
    
    public List<Department> findActiveDepartments() {
        return departmentRepository.findByActive(true);
    }
    
    public Optional<Department> findByName(String name) {
        return departmentRepository.findByName(name);
    }
}
