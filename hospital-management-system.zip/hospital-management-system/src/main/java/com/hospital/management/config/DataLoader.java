package com.hospital.management.config;

import com.hospital.management.model.Role;
import com.hospital.management.service.UserService;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
public class DataLoader implements ApplicationRunner {

    private final UserService userService;

    public DataLoader(UserService userService) {
        this.userService = userService;
    }

    @Override
    public void run(ApplicationArguments args) throws Exception {
        // create default admin if not exists
        userService.findByUsername("admin").orElseGet(() -> userService.createUser("admin", "admin", Role.ROLE_ADMIN));
    }
}
