package com.hospital.management.service;

import com.hospital.management.model.Doctor;
import com.hospital.management.repository.DoctorRepository;
import com.hospital.management.exception.UniqueConstraintViolationException;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class DoctorService {
    
    @Autowired
    private DoctorRepository doctorRepository;

    @PersistenceContext
    private EntityManager entityManager;
    
    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll(org.springframework.data.domain.Sort.by("id").ascending());
    }
    
    public Optional<Doctor> getDoctorById(Long id) {
        return doctorRepository.findById(id);
    }
    
    public Doctor createDoctor(Doctor doctor) {
        if (doctor.getId() != null && doctorRepository.existsById(doctor.getId())) {
            throw new UniqueConstraintViolationException("A doctor with this ID already exists");
        }
        return doctorRepository.save(doctor);
    }
    
    public Doctor updateDoctor(Long id, Doctor doctorDetails) {
        Doctor doctor = doctorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Doctor not found with id: " + id));
        
        // No duplicate checks except ID (handled by DB primary key)
        if (doctorDetails.getPhone() != null) doctor.setPhone(doctorDetails.getPhone());
        if (doctorDetails.getEmail() != null) doctor.setEmail(doctorDetails.getEmail());
        
        // Partial update: only overwrite provided fields
        if (doctorDetails.getFirstName() != null) doctor.setFirstName(doctorDetails.getFirstName());
        if (doctorDetails.getLastName() != null) doctor.setLastName(doctorDetails.getLastName());
        if (doctorDetails.getSpecialization() != null) doctor.setSpecialization(doctorDetails.getSpecialization());
        if (doctorDetails.getQualification() != null) doctor.setQualification(doctorDetails.getQualification());
        if (doctorDetails.getDepartment() != null) doctor.setDepartment(doctorDetails.getDepartment());
        if (doctorDetails.getExperienceYears() != null) doctor.setExperienceYears(doctorDetails.getExperienceYears());
        if (doctorDetails.getAddress() != null) doctor.setAddress(doctorDetails.getAddress());
        if (doctorDetails.getAvailable() != null) doctor.setAvailable(doctorDetails.getAvailable());
        
        return doctorRepository.save(doctor);
    }
    
    @Transactional
    public void deleteDoctor(Long id) {
        // Delete the doctor
        doctorRepository.deleteById(id);
        
        // Reindex remaining doctors to have consecutive IDs starting from 1
        reindexDoctors();
    }
    
    private void reindexDoctors() {
        // Disable foreign key checks temporarily
        entityManager.createNativeQuery("SET FOREIGN_KEY_CHECKS = 0").executeUpdate();
        
        try {
            // Get all remaining doctors ordered by ID
            List<Doctor> doctors = doctorRepository.findAll(
                org.springframework.data.domain.Sort.by("id").ascending());
            
            if (doctors.isEmpty()) {
                // Reset auto increment if no doctors left
                entityManager.createNativeQuery("ALTER TABLE doctors AUTO_INCREMENT = 1").executeUpdate();
                return;
            }
            
            // First pass: Update to temporary IDs (add large offset to avoid conflicts)
            long tempOffset = 1000000L;
            for (Doctor doctor : doctors) {
                Long oldId = doctor.getId();
                Long tempId = oldId + tempOffset;
                
                if (!oldId.equals(tempId)) {
                    // Update appointments that reference this doctor
                    entityManager.createNativeQuery(
                        "UPDATE appointments SET doctor_id = :tempId WHERE doctor_id = :oldId")
                        .setParameter("tempId", tempId)
                        .setParameter("oldId", oldId)
                        .executeUpdate();
                    
                    // Update doctor ID to temporary value
                    entityManager.createNativeQuery(
                        "UPDATE doctors SET id = :tempId WHERE id = :oldId")
                        .setParameter("tempId", tempId)
                        .setParameter("oldId", oldId)
                        .executeUpdate();
                }
            }
            
            // Second pass: Update from temporary IDs to final sequential IDs
            // Query doctors again after first pass (they now have temporary IDs)
            @SuppressWarnings("unchecked")
            List<Object[]> tempDoctors = entityManager.createNativeQuery(
                "SELECT id FROM doctors ORDER BY id ASC").getResultList();
            
            for (int i = 0; i < tempDoctors.size(); i++) {
                Long tempId = ((Number) tempDoctors.get(i)[0]).longValue();
                Long newId = (long) (i + 1);
                
                // Update appointments that reference this doctor
                entityManager.createNativeQuery(
                    "UPDATE appointments SET doctor_id = :newId WHERE doctor_id = :tempId")
                    .setParameter("newId", newId)
                    .setParameter("tempId", tempId)
                    .executeUpdate();
                
                // Update doctor ID to final sequential value
                entityManager.createNativeQuery(
                    "UPDATE doctors SET id = :newId WHERE id = :tempId")
                    .setParameter("newId", newId)
                    .setParameter("tempId", tempId)
                    .executeUpdate();
            }
            
            // Reset auto increment (use tempDoctors size since that's the current count)
            int count = tempDoctors.size();
            entityManager.createNativeQuery(
                "ALTER TABLE doctors AUTO_INCREMENT = :nextId")
                .setParameter("nextId", count + 1)
                .executeUpdate();
            
            // Clear persistence context to reload entities with new IDs
            entityManager.clear();
        } finally {
            // Re-enable foreign key checks
            entityManager.createNativeQuery("SET FOREIGN_KEY_CHECKS = 1").executeUpdate();
        }
    }
    
    public List<Doctor> searchDoctors(String searchTerm) {
        return doctorRepository.findAll().stream()
                .filter(doctor -> 
                    containsIgnoreCase(doctor.getFirstName(), searchTerm) ||
                    containsIgnoreCase(doctor.getLastName(), searchTerm) ||
                    containsIgnoreCase(doctor.getSpecialization(), searchTerm) ||
                    containsIgnoreCase(doctor.getEmail(), searchTerm))
                .toList();
    }
    
    public List<Doctor> findBySpecialization(String specialization) {
        return doctorRepository.findBySpecialization(specialization);
    }
    
    private boolean containsIgnoreCase(String str, String searchTerm) {
        return str != null && str.toLowerCase().contains(searchTerm.toLowerCase());
    }
    
    public List<Doctor> findByDepartmentId(Long departmentId) {
        return doctorRepository.findByDepartmentId(departmentId);
    }
    
    public List<Doctor> findAvailableDoctors() {
        return doctorRepository.findByAvailable(true);
    }
}
