package com.hospital.management.repository;

import com.hospital.management.model.Appointment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Long> {

    @Override
    @EntityGraph(attributePaths = {"patient", "doctor"})
    List<Appointment> findAll();

    @Override
    @EntityGraph(attributePaths = {"patient", "doctor"})
    List<Appointment> findAll(Sort sort);
    
    @EntityGraph(attributePaths = {"patient", "doctor"})
    List<Appointment> findByPatientId(Long patientId);
    
    @EntityGraph(attributePaths = {"patient", "doctor"})
    List<Appointment> findByDoctorId(Long doctorId);
    
    @EntityGraph(attributePaths = {"patient", "doctor"})
    List<Appointment> findByStatus(String status);

    @EntityGraph(attributePaths = {"patient", "doctor"})
    Page<Appointment> findByPatientId(Long patientId, Pageable pageable);
    @EntityGraph(attributePaths = {"patient", "doctor"})
    Page<Appointment> findByDoctorId(Long doctorId, Pageable pageable);
    @EntityGraph(attributePaths = {"patient", "doctor"})
    Page<Appointment> findByStatus(String status, Pageable pageable);
    
    @EntityGraph(attributePaths = {"patient", "doctor"})
    List<Appointment> findByAppointmentDateTimeBetween(
            LocalDateTime start, LocalDateTime end);
    
    @EntityGraph(attributePaths = {"patient", "doctor"})
    List<Appointment> findByDoctorIdAndAppointmentDateTimeBetween(
            Long doctorId, LocalDateTime start, LocalDateTime end);
}
