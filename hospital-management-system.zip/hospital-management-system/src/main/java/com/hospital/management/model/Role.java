package com.hospital.management.model;

public enum Role {
    ROLE_ADMIN,
    ROLE_DOCTOR,
    ROLE_RECEPTION
}
