package com.hospital.management.controller;

import com.hospital.management.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import jakarta.validation.Valid;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class WebController {
    
    @Autowired
    private PatientService patientService;
    
    @Autowired
    private DoctorService doctorService;
    
    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/register")
    public String registerForm(org.springframework.ui.Model model) {
        model.addAttribute("username", "");
        return "register";
    }

    @PostMapping("/register/process")
    public String registerProcess(@org.springframework.web.bind.annotation.RequestParam String username,
                                  @org.springframework.web.bind.annotation.RequestParam String password,
                                  org.springframework.ui.Model model,
                                  org.springframework.web.servlet.mvc.support.RedirectAttributes redirectAttrs) {
        // create user with RECEPTION role by default
        try {
            com.hospital.management.model.User existing = userService.findByUsername(username).orElse(null);
            if (existing != null) {
                model.addAttribute("errorMessage", "Username already exists");
                return "register";
            }
            userService.createUser(username, password, com.hospital.management.model.Role.ROLE_RECEPTION);
            redirectAttrs.addFlashAttribute("successMessage", "Registration successful. Please login.");
            return "redirect:/login";
        } catch (Exception e) {
            model.addAttribute("errorMessage", "Registration failed: " + e.getMessage());
            return "register";
        }
    }
    
    @Autowired
    private DepartmentService departmentService;
    
    @Autowired
    private AppointmentService appointmentService;

    @Autowired
    private com.hospital.management.service.UserService userService;
    
    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("patientCount", patientService.getAllPatients().size());
        model.addAttribute("doctorCount", doctorService.getAllDoctors().size());
        model.addAttribute("departmentCount", departmentService.getAllDepartments().size());
        model.addAttribute("appointmentCount", appointmentService.getAllAppointments().size());
        return "index";
    }
    
    @GetMapping("/departments")
    public String departments(Model model) {
        model.addAttribute("departments", departmentService.getAllDepartments());
        return "departments";
    }
    
    @GetMapping("/departments/new")
    public String newDepartmentForm(Model model) {
        model.addAttribute("department", new com.hospital.management.model.Department());
        return "department-form";
    }

    @PostMapping("/departments")
    public String createDepartment(@Valid com.hospital.management.model.Department department,
                                   BindingResult result,
                                   RedirectAttributes redirectAttrs) {
        if (result.hasErrors()) {
            return "department-form";
        }
        departmentService.createDepartment(department);
        redirectAttrs.addFlashAttribute("successMessage", "Department created successfully.");
        return "redirect:/departments";
    }


}
