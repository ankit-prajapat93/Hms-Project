-- Hospital Management System Database Schema

-- Create database if not exists
CREATE DATABASE IF NOT EXISTS hospital_db;
USE hospital_db;

-- Departments Table
CREATE TABLE IF NOT EXISTS departments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    description VARCHAR(1000),
    active BOOLEAN NOT NULL DEFAULT TRUE,
    INDEX idx_department_active (active),
    INDEX idx_department_name (name)
);

-- Doctors Table
CREATE TABLE IF NOT EXISTS doctors (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(255) NOT NULL,
    last_name VARCHAR(255) NOT NULL,
    specialization VARCHAR(255) NOT NULL,
    qualification VARCHAR(255) NOT NULL,
    phone VARCHAR(10) NOT NULL UNIQUE,
    email VARCHAR(255) UNIQUE,
    department_id BIGINT,
    experience_years INT NOT NULL,
    address VARCHAR(500),
    available BOOLEAN NOT NULL DEFAULT TRUE,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
    INDEX idx_doctor_phone (phone),
    INDEX idx_doctor_email (email),
    INDEX idx_doctor_specialization (specialization),
    INDEX idx_doctor_available (available)
);

-- Patients Table
CREATE TABLE IF NOT EXISTS patients (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(255) NOT NULL,
    last_name VARCHAR(255) NOT NULL,
    date_of_birth DATE NOT NULL,
    gender VARCHAR(50) NOT NULL,
    phone VARCHAR(10) NOT NULL UNIQUE,
    email VARCHAR(255) UNIQUE,
    address VARCHAR(500) NOT NULL,
    blood_group VARCHAR(100),
    medical_history VARCHAR(1000),
    registration_date DATE NOT NULL,
    INDEX idx_patient_phone (phone),
    INDEX idx_patient_email (email),
    INDEX idx_patient_blood_group (blood_group)
);

-- Appointments Table
CREATE TABLE IF NOT EXISTS appointments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    patient_id BIGINT NOT NULL,
    doctor_id BIGINT NOT NULL,
    appointment_date_time DATETIME NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'SCHEDULED',
    reason VARCHAR(500),
    notes VARCHAR(1000),
    created_at DATETIME NOT NULL,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE,
    INDEX idx_appointment_patient (patient_id),
    INDEX idx_appointment_doctor (doctor_id),
    INDEX idx_appointment_status (status),
    INDEX idx_appointment_datetime (appointment_date_time)
);

-- Insert sample departments
INSERT INTO departments (name, description, active) VALUES
('Cardiology', 'Department specializing in heart and cardiovascular diseases', TRUE),
('Neurology', 'Department specializing in nervous system disorders', TRUE),
('Orthopedics', 'Department specializing in musculoskeletal system', TRUE),
('Pediatrics', 'Department specializing in children healthcare', TRUE),
('General Medicine', 'Department for general health issues', TRUE)
ON DUPLICATE KEY UPDATE name=name;
